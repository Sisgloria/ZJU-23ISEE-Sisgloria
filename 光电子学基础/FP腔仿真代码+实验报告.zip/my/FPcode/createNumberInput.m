function [labelHandle, fieldHandle] = createNumberInput(parentHandle, labelText, defaultValue, limits)
% 创建一个标签和一个数值输入框
%
% 输入：
%   parentHandle  - 父容器，例如uipanel
%   labelText     - 标签显示文字
%   defaultValue  - 输入框默认值
%   limits        - 输入框允许范围
%
% 输出：
%   labelHandle   - 标签句柄
%   fieldHandle   - 数值输入框句柄

labelHandle = uilabel(parentHandle, ...
    'Text', labelText, ...
    'HorizontalAlignment', 'right');

fieldHandle = uieditfield(parentHandle, 'numeric', ...
    'Value', defaultValue, ...
    'Limits', limits);

end