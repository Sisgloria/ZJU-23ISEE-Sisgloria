%% FP_GUI_script_main.m
% FP腔透射率仿真GUI脚本

clc;
clear;
close all;

%% 主窗口
% 根据屏幕尺寸设置窗口大小，避免窗口过大导致显示不全
screenSize = get(0, 'ScreenSize');

figW = min(1280, screenSize(3) - 100);
figH = min(760,  screenSize(4) - 100);

if figW < 1050
    figW = screenSize(3) - 60;
end

if figH < 680
    figH = screenSize(4) - 70;
end

fig = uifigure( ...
    'Name', 'Fabry-Perot Cavity Simulation', ...
    'Position', [60 50 figW figH], ...
    'Color', [0.96 0.96 0.96]);

%% 绘图区
% 上方坐标区用于显示两组FP腔透射率曲线
ax = uiaxes(fig);

title(ax, 'Transmission of Fabry-Perot Cavity');
xlabel(ax, 'Wavelength / nm');
ylabel(ax, 'Transmission T');
grid(ax, 'on');
box(ax, 'on');

ax.FontSize = 11;
ax.LineWidth = 1;
ax.Layer = 'top';
ax.XAxisLocation = 'bottom';
ax.YAxisLocation = 'left';

%% 控制面板
% 下方控制面板用于放置参数输入框和功能按钮
controlPanel = uipanel(fig, ...
    'Title', 'Parameter Settings and Functions', ...
    'FontWeight', 'bold');

%% 波长参数
% createNumberInput用于创建“标签 + 数值输入框”，减少重复代码
[lambdaMinLabel, lambdaMinField] = createNumberInput( ...
    controlPanel, '最小波长', 50, [0 Inf]);

[lambdaMaxLabel, lambdaMaxField] = createNumberInput( ...
    controlPanel, '最大波长', 1000, [0 Inf]);

[lambdaStepLabel, lambdaStepField] = createNumberInput( ...
    controlPanel, '波长步长', 0.01, [0 Inf]);

unitLabel = uilabel(controlPanel, ...
    'Text', '单位：nm', ...
    'HorizontalAlignment', 'left');

%% 曲线1参数
curve1Label = uilabel(controlPanel, ...
    'Text', 'Curve 1', ...
    'FontWeight', 'bold', ...
    'HorizontalAlignment', 'center');

[A1Label, A1Field] = createNumberInput(controlPanel, '吸收损耗A', 0.02, [0 0.999]);
[r1Label, r1Field] = createNumberInput(controlPanel, '反射率r', 0.85, [0 0.999]);
[n1Label, n1Field] = createNumberInput(controlPanel, '折射率n', 1.45, [1 Inf]);
[d1Label, d1Field] = createNumberInput(controlPanel, '腔长d/nm', 500, [eps Inf]);
[theta1Label, theta1Field] = createNumberInput(controlPanel, '入射角θ', 0, [0 90]);
[phi1Label, phi1Field] = createNumberInput(controlPanel, '相位φ', 0, [-Inf Inf]);

%% 曲线2参数
curve2Label = uilabel(controlPanel, ...
    'Text', 'Curve 2', ...
    'FontWeight', 'bold', ...
    'HorizontalAlignment', 'center');

[A2Label, A2Field] = createNumberInput(controlPanel, '吸收损耗A', 0.02, [0 0.999]);
[r2Label, r2Field] = createNumberInput(controlPanel, '反射率r', 0.85, [0 0.999]);
[n2Label, n2Field] = createNumberInput(controlPanel, '折射率n', 1.45, [1 Inf]);
[d2Label, d2Field] = createNumberInput(controlPanel, '腔长d/nm', 500, [eps Inf]);
[theta2Label, theta2Field] = createNumberInput(controlPanel, '入射角θ', 0, [0 90]);
[phi2Label, phi2Field] = createNumberInput(controlPanel, '相位φ', 0, [-Inf Inf]);

%% 功能按钮
% Calculate保留为手动刷新按钮；输入框数值变化后也会自动刷新图像
calculateButton = uibutton(controlPanel, 'push', ...
    'Text', 'Calculate');

toggleButton = uibutton(controlPanel, 'push', ...
    'Text', 'Hide Curve 2');

saveImageButton = uibutton(controlPanel, 'push', ...
    'Text', 'Save Image');

saveDataButton = uibutton(controlPanel, 'push', ...
    'Text', 'Save Data');

resetButton = uibutton(controlPanel, 'push', ...
    'Text', 'Reset');

%% 保存界面数据
% 用结构体app保存控件句柄和计算结果，便于各个回调函数共享数据
app.fig = fig;
app.ax = ax;
app.controlPanel = controlPanel;

app.lambdaMinLabel = lambdaMinLabel;
app.lambdaMinField = lambdaMinField;
app.lambdaMaxLabel = lambdaMaxLabel;
app.lambdaMaxField = lambdaMaxField;
app.lambdaStepLabel = lambdaStepLabel;
app.lambdaStepField = lambdaStepField;
app.unitLabel = unitLabel;

app.curve1Label = curve1Label;
app.A1Label = A1Label;
app.A1Field = A1Field;
app.r1Label = r1Label;
app.r1Field = r1Field;
app.n1Label = n1Label;
app.n1Field = n1Field;
app.d1Label = d1Label;
app.d1Field = d1Field;
app.theta1Label = theta1Label;
app.theta1Field = theta1Field;
app.phi1Label = phi1Label;
app.phi1Field = phi1Field;

app.curve2Label = curve2Label;
app.A2Label = A2Label;
app.A2Field = A2Field;
app.r2Label = r2Label;
app.r2Field = r2Field;
app.n2Label = n2Label;
app.n2Field = n2Field;
app.d2Label = d2Label;
app.d2Field = d2Field;
app.theta2Label = theta2Label;
app.theta2Field = theta2Field;
app.phi2Label = phi2Label;
app.phi2Field = phi2Field;

app.calculateButton = calculateButton;
app.toggleButton = toggleButton;
app.saveImageButton = saveImageButton;
app.saveDataButton = saveDataButton;
app.resetButton = resetButton;

% 保存最新计算结果和曲线对象
app.lambda = [];
app.T1 = [];
app.T2 = [];
app.line1 = [];
app.line2 = [];
app.showCurve2 = true;

setappdata(fig, 'app', app);

%% 回调函数设置
calculateButton.ButtonPushedFcn = @(src, event) calculateCallback(fig);
toggleButton.ButtonPushedFcn = @(src, event) toggleCurve2Callback(fig, src);
saveImageButton.ButtonPushedFcn = @(src, event) saveImageCallback(fig);
saveDataButton.ButtonPushedFcn = @(src, event) saveDataCallback(fig);
resetButton.ButtonPushedFcn = @(src, event) resetCallback(fig, toggleButton);

% 所有输入框在数值变化后都会自动重新计算
allFields = {lambdaMinField, lambdaMaxField, lambdaStepField, ...
             A1Field, r1Field, n1Field, d1Field, theta1Field, phi1Field, ...
             A2Field, r2Field, n2Field, d2Field, theta2Field, phi2Field};

for k = 1:numel(allFields)
    allFields{k}.ValueChangedFcn = @(src, event) calculateCallback(fig);
end

% 窗口大小变化时重新调整控件位置
fig.SizeChangedFcn = @(src, event) resizeGUI(fig);

resizeGUI(fig);
calculateCallback(fig);

%% 局部函数

function resizeGUI(fig)
    app = getappdata(fig, 'app');

    if isempty(app)
        return;
    end

    figPos = fig.Position;
    figW = figPos(3);
    figH = figPos(4);

    outerMarginX = 20;
    bottomMargin = 10;
    topMargin = 20;

    % 固定下方面板高度，使按钮和输入框位置稳定
    panelH = 220;
    panelX = outerMarginX;
    panelY = bottomMargin;
    panelW = figW - 2 * outerMarginX;

    app.controlPanel.Position = [panelX, panelY, panelW, panelH];

    % 给横坐标和下方面板之间留出空间，避免坐标轴被遮挡
    axesGap = 78;
    axShrink = 70;

    axX = outerMarginX;
    axY = panelY + panelH + axesGap;
    axW = figW - 2 * outerMarginX - axShrink;
    axH = figH - axY - topMargin;

    if axH < 250
        axH = 250;
    end

    app.ax.Position = [axX, axY, axW, axH];

    cw = app.controlPanel.Position(3);
    ch = app.controlPanel.Position(4);

    rowWave = ch - 55;
    rowCurve1 = ch - 98;
    rowCurve2 = ch - 140;
    rowButton = 15;

    labelH = 22;
    leftX = 25;
    leftLabelW = 80;

    app.curve1Label.Position = [leftX, rowCurve1, leftLabelW, labelH];
    app.curve2Label.Position = [leftX, rowCurve2, leftLabelW, labelH];

    %% 波长参数行
    waveY = rowWave;

    waveX1 = 300;
    waveX2 = 500;
    waveX3 = 700;
    unitX  = 875;

    placePair(app.lambdaMinLabel, app.lambdaMinField, waveX1, waveY, 72, 70);
    placePair(app.lambdaMaxLabel, app.lambdaMaxField, waveX2, waveY, 72, 70);
    placePair(app.lambdaStepLabel, app.lambdaStepField, waveX3, waveY, 72, 70);
    app.unitLabel.Position = [unitX, waveY, 90, labelH];

    %% 曲线参数行
    % 固定紧凑排布，避免最右侧“相位φ”被裁掉
    x1 = 115;   % 吸收损耗A
    x2 = 258;   % 反射率r
    x3 = 390;   % 折射率n
    x4 = 522;   % 腔长d/nm
    x5 = 665;   % 入射角θ
    x6 = 795;   % 相位φ

    fieldW = 50;

    placePair(app.A1Label, app.A1Field, x1, rowCurve1, 82, fieldW);
    placePair(app.r1Label, app.r1Field, x2, rowCurve1, 66, fieldW);
    placePair(app.n1Label, app.n1Field, x3, rowCurve1, 66, fieldW);
    placePair(app.d1Label, app.d1Field, x4, rowCurve1, 76, fieldW);
    placePair(app.theta1Label, app.theta1Field, x5, rowCurve1, 70, fieldW);
    placePair(app.phi1Label, app.phi1Field, x6, rowCurve1, 54, fieldW);

    placePair(app.A2Label, app.A2Field, x1, rowCurve2, 82, fieldW);
    placePair(app.r2Label, app.r2Field, x2, rowCurve2, 66, fieldW);
    placePair(app.n2Label, app.n2Field, x3, rowCurve2, 66, fieldW);
    placePair(app.d2Label, app.d2Field, x4, rowCurve2, 76, fieldW);
    placePair(app.theta2Label, app.theta2Field, x5, rowCurve2, 70, fieldW);
    placePair(app.phi2Label, app.phi2Field, x6, rowCurve2, 54, fieldW);

    %% 按钮行
    btnW = 84;
    btnH = 25;
    btnGap = 4;
    totalW = 5 * btnW + 4 * btnGap;
    startX = max(10, (cw - totalW) / 2);

    app.calculateButton.Position = [startX + 0 * (btnW + btnGap), rowButton, btnW, btnH];
    app.toggleButton.Position    = [startX + 1 * (btnW + btnGap), rowButton, btnW, btnH];
    app.saveImageButton.Position = [startX + 2 * (btnW + btnGap), rowButton, btnW, btnH];
    app.saveDataButton.Position  = [startX + 3 * (btnW + btnGap), rowButton, btnW, btnH];
    app.resetButton.Position     = [startX + 4 * (btnW + btnGap), rowButton, btnW, btnH];
end

function placePair(labelHandle, fieldHandle, x, y, labelW, fieldW)
    % 将一个标签和对应输入框放到指定位置
    labelH = 22;
    fieldH = 22;
    gap = 4;

    labelHandle.Position = [x, y, labelW, labelH];
    fieldHandle.Position = [x + labelW + gap, y, fieldW, fieldH];
end

function calculateCallback(fig)
    app = getappdata(fig, 'app');

    lambdaMin = app.lambdaMinField.Value;
    lambdaMax = app.lambdaMaxField.Value;
    lambdaStep = app.lambdaStepField.Value;

    if lambdaMin < 0 || lambdaMax <= 0 || lambdaStep <= 0 || lambdaMin >= lambdaMax
        uialert(fig, ...
            'Invalid wavelength range. Max must be larger than Min, and Step must be positive.', ...
            'Parameter Error');
        return;
    end

    A1 = app.A1Field.Value;
    r1 = app.r1Field.Value;
    n1 = app.n1Field.Value;
    d1 = app.d1Field.Value;
    theta1 = app.theta1Field.Value;
    phi1 = app.phi1Field.Value;

    A2 = app.A2Field.Value;
    r2 = app.r2Field.Value;
    n2 = app.n2Field.Value;
    d2 = app.d2Field.Value;
    theta2 = app.theta2Field.Value;
    phi2 = app.phi2Field.Value;

    if ~checkParameters(fig, A1, r1, n1, d1, theta1)
        return;
    end

    if ~checkParameters(fig, A2, r2, n2, d2, theta2)
        return;
    end

    % 波长不能从0直接参与公式计算，否则会出现除零问题
    if lambdaMin == 0
        lambdaStart = lambdaStep;
    else
        lambdaStart = lambdaMin;
    end

    lambda = lambdaStart:lambdaStep:lambdaMax;

    T1 = calculateFPTransmission(lambda, A1, r1, n1, d1, theta1, phi1);
    T2 = calculateFPTransmission(lambda, A2, r2, n2, d2, theta2, phi2);

    cla(app.ax);

    app.line1 = plot(app.ax, lambda, T1, 'b-', 'LineWidth', 1.5);
    hold(app.ax, 'on');
    app.line2 = plot(app.ax, lambda, T2, 'r-', 'LineWidth', 1.5);
    hold(app.ax, 'off');

    if app.showCurve2
        app.line2.Visible = 'on';
        legend(app.ax, {'Curve 1', 'Curve 2'}, 'Location', 'best');
    else
        app.line2.Visible = 'off';
        legend(app.ax, {'Curve 1'}, 'Location', 'best');
    end

    title(app.ax, 'Transmission of Fabry-Perot Cavity');
    xlabel(app.ax, 'Wavelength / nm');
    ylabel(app.ax, 'Transmission T');
    grid(app.ax, 'on');
    box(app.ax, 'on');

    if lambdaMin == 0
        xlim(app.ax, [0, lambdaMax]);
    else
        xlim(app.ax, [lambdaMin, lambdaMax]);
    end

    ymax = max([max(T1), max(T2), 1]);

    ylim(app.ax, [0, ymax * 1.05]);
    yticks(app.ax, 0:0.1:ceil(ymax * 10) / 10);

    app.ax.XAxisLocation = 'bottom';
    app.ax.YAxisLocation = 'left';
    app.ax.FontSize = 11;
    app.ax.LineWidth = 1;
    app.ax.Layer = 'top';

    % 保存最新结果，供保存图像和保存数据按钮使用
    app.lambda = lambda;
    app.T1 = T1;
    app.T2 = T2;

    setappdata(fig, 'app', app);
end

function ok = checkParameters(fig, A, r, n, d, theta)
    ok = false;

    if A < 0 || A >= 1
        uialert(fig, 'Absorption loss A must satisfy 0 <= A < 1.', ...
            'Parameter Error');
        return;
    end

    if r < 0 || r >= 1
        uialert(fig, 'Reflectance r must satisfy 0 <= r < 1.', ...
            'Parameter Error');
        return;
    end

    if n < 1
        uialert(fig, 'Refractive index n must be larger than or equal to 1.', ...
            'Parameter Error');
        return;
    end

    if d <= 0
        uialert(fig, 'Cavity length d must be larger than 0.', ...
            'Parameter Error');
        return;
    end

    if theta < 0 || theta > 90
        uialert(fig, 'Incident angle theta must be between 0 and 90 degrees.', ...
            'Parameter Error');
        return;
    end

    ok = true;
end

function toggleCurve2Callback(fig, button)
    app = getappdata(fig, 'app');

    app.showCurve2 = ~app.showCurve2;

    if app.showCurve2
        button.Text = 'Hide Curve 2';

        if ~isempty(app.line2) && isgraphics(app.line2)
            app.line2.Visible = 'on';
        end

        legend(app.ax, {'Curve 1', 'Curve 2'}, 'Location', 'best');
    else
        button.Text = 'Show Curve 2';

        if ~isempty(app.line2) && isgraphics(app.line2)
            app.line2.Visible = 'off';
        end

        legend(app.ax, {'Curve 1'}, 'Location', 'best');
    end

    setappdata(fig, 'app', app);
end

function saveImageCallback(fig)
    app = getappdata(fig, 'app');

    if isempty(app.lambda)
        calculateCallback(fig);
        app = getappdata(fig, 'app');
    end

    [file, path] = uiputfile( ...
        {'*.png', 'PNG Image (*.png)'; ...
         '*.jpg', 'JPG Image (*.jpg)'; ...
         '*.pdf', 'PDF File (*.pdf)'}, ...
        'Save Image');

    if isequal(file, 0) || isequal(path, 0)
        return;
    end

    fullFileName = fullfile(path, file);

    % 只保存坐标区图像，不保存整个GUI窗口
    exportgraphics(app.ax, fullFileName, 'Resolution', 300);

    uialert(fig, 'Image saved successfully.', 'Success');
end

function saveDataCallback(fig)
    app = getappdata(fig, 'app');

    if isempty(app.lambda)
        calculateCallback(fig);
        app = getappdata(fig, 'app');
    end

    [file, path] = uiputfile( ...
        {'*.txt', 'Text File (*.txt)'; ...
         '*.csv', 'CSV File (*.csv)'}, ...
        'Save Data');

    if isequal(file, 0) || isequal(path, 0)
        return;
    end

    fullFileName = fullfile(path, file);

    % 将波长和两条曲线的数据整理成表格
    dataTable = table(app.lambda(:), app.T1(:), app.T2(:), ...
        'VariableNames', {'lambda_nm', 'T_curve1', 'T_curve2'});

    writetable(dataTable, fullFileName);

    uialert(fig, 'Data saved successfully.', 'Success');
end

function resetCallback(fig, toggleButton)
    app = getappdata(fig, 'app');

    % 恢复第4节仿真基准参数
    app.lambdaMinField.Value = 50;
    app.lambdaMaxField.Value = 1000;
    app.lambdaStepField.Value = 0.01;

    app.A1Field.Value = 0.02;
    app.r1Field.Value = 0.85;
    app.n1Field.Value = 1.45;
    app.d1Field.Value = 500;
    app.theta1Field.Value = 0;
    app.phi1Field.Value = 0;

    app.A2Field.Value = 0.02;
    app.r2Field.Value = 0.85;
    app.n2Field.Value = 1.45;
    app.d2Field.Value = 500;
    app.theta2Field.Value = 0;
    app.phi2Field.Value = 0;

    app.showCurve2 = true;
    toggleButton.Text = 'Hide Curve 2';

    setappdata(fig, 'app', app);

    resizeGUI(fig);
    calculateCallback(fig);
end