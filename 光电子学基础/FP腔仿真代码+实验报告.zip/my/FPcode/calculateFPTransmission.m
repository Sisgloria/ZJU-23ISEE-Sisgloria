function T = calculateFPTransmission(lambda, A, r, n, d, theta, phi)
% 计算FP腔透射率
%
% 输入：
%   lambda - 波长数组，单位为nm
%   A      - 吸收损耗
%   r      - 反射率
%   n      - 折射率
%   d      - 腔长，单位为nm
%   theta  - 入射角，单位为度
%   phi    - 相位偏移
%
% 输出：
%   T      - 对应波长下的透射率数组

thetaRad = deg2rad(theta);

opticalPath = n * d * cos(thetaRad);
phaseDifference = (2 * pi ./ lambda) * opticalPath - phi;

numerator = (1 - A / (1 - r))^2;
denominator = 1 + (4 * r / (1 - r)^2) .* sin(phaseDifference).^2;

T = numerator ./ denominator;

% 透射率在物理意义上不应为负
T(T < 0) = 0;

end